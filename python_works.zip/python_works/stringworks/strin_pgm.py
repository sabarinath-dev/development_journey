
word="helloworld"
#     0123456789

print("method1")

for ch in word:

    print(ch)


print("metohd2 using index")

for index in range(0,len(word)):

    print(word[index])