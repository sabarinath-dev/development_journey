

"""
String

sequence of characters

"""

# object
# oops (object oriented programming) ?

# class ,object

"""
OOP is a programming paradigm(style of coding) that allows us to bring real-world-entities in to 
programming by using classes and objects

class:plan,design pattern,template
object:realworld entity

"""

# class str:
    # def capitalize()
    # def casefold()
    # def upper()
    # def lower()
    # def isalpha() => return True if string object is alphabet return False otherwise
    # def isdigit()=>retrun True if string object is digit return False otherwise
    # def isalnum()=>return True if string is alphabet or number return False otherwise
    # def index(str)=>return index of first occurance of substr else return valuerror
    # def count(str)=>return number of times sub string occurs in the string object
    # def startswith(prefix)=>return True if string object starts with given prefix else return False
    # def endswith(suffix)=> return True if string ends with given suffix else return False
    # def strip(char)=> return copy of string in which char removed from both end
    # def lstrip(char)=> return copy of string in which cahr removed from begining
    # def rstrip(char)=> return copy of string in which cahr removed from end




name=">luminar>technolab>"
#     0123456789012345

new_name = name.lstrip(">")
print(new_name)

# new_name=name.strip(">")
# print(new_name)

# print(name.endswith("lab"))
# print(name.startswith("lum"))

# occ_count = name.count("act")
# print(occ_count)
# index_pos=name.index("lab")
# print(index_pos)
# print(name.isalnum())
# print(name.isdigit())
# print(name.isalpha())

# upp_name=name.upper()
# print(upp_name)

# low_name=name.lower()

# print(low_name)

# new_name=name.capitalize()

# new_name=name.casefold()

# print(new_name)




# upper()
# lower()
