



def is_anagram_text(word1,word2):

    is_anagram=True

    is_anagram=sorted(word1)==sorted(word2)

    return is_anagram


print(is_anagram_text("silents","listen"))

# pangram
# anagram
# palindrome
# kangraooword

