

signal = input("enter signal ")

if signal == "red":

    print("STOP XXXXXX")

elif signal == "green":

    print("GO >>>>")

elif signal == "yellow":

    print("Wait !!!!!")

else:
    print("invalid signal")