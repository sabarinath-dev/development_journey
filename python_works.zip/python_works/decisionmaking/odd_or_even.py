

# read num1 display num is odd if number is odd else display number is even


num = int(input("enter number"))

if num%2 == 0:

    print(num,"is even")

else:

    print(num,"is odd")


