

# read a number

# display PING if num is / by 3
# display PONG if number is / by 5
# display PINGPONG if number is / by 15
# display invalid 


number = int(input("enter number")) #15

if number % 15 ==0: #15%3==0

    print("PINGPONG")

elif number % 5 ==0:

    print("PONG")

elif number % 3 ==0:

    print("PING")

# programs
