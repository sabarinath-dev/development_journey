

# syntax if..else


"""
if condition:
    stmt1
    stmt2
else:
    stmt3
    stmt4
"""

age = int(input("enter age")) # 28


if age  > 18: # 28 > 18

    print("eligible for voting")# el 

else:
    
    print("not eligible for voting")

