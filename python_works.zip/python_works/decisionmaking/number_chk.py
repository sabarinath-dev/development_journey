
number = int(input("enter number"))


if number > 0:

    print("+ve")

elif number < 0:

    print("-ve")

elif number == 0:

    print("number is zero")

else:
    print("invalid number")