

# set two number num1 and num2 display largest number

num1 = int(input("enter number1"))#10

num2 = int(input("enter number2"))#50

if num1 > num2:# 10 > 50

    print("num1=",num1,"is largest")

else:

    print("num2",num2,"is largest")#