# line comment
# function for displaying message in console = print("message")

# notations
# snake_case >>>
# PascalCase >>>
# kebab-case XXXX
# camelCase XXXX 

# identifiers user
# variable_name => snake_case
# function_name=> snake_case
# ClassName => PascalCase
# method_name=>snake_case





