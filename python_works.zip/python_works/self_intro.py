
# good morning all i am jhon doe from london


print("good morning all i am jhon from london")