

# display hello world 5 times

count = 1

while(count<=5):# 1<=5  2<=5  3<=5  4<=5  5<=5 6<=5

    print("HELLO WORLD") #HW HW HW HW HW

    count += 1# 2 3 4 5 6

