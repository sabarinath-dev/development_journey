

# chk class room from 10 to 50

# display numbers from 50 to 100

count = 10

while(count<=50):

    print("chking class room",count)

    count +=1
