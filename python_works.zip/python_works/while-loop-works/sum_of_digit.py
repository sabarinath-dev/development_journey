
# read number
# set sum as 0

# loop num !=0
    #extract digit from number
    #add digit with sum
    # flooring number


# display sum
