

number = int(input("enter number"))

# 1,,,,,,,number'

i =1 

while(i<=number):

    if number % i ==0:

        print(i)  

    i+=1

# sample input
# num1=12
# num2=24
# 1,2,3,4,6,12(gcd)
# common divisors

# num1=16
# num2=24
# 1,2,4,8
# common diviso