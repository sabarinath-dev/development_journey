
movie={
       "title":"kanthara2","year":2025,
       "director":"rishabshetty",
       "languange":"kannanda",
       "rating":5.5
       }
# chk key exist or not

# if "genre" in movie:

#     print("exist")

# else:
#     print("not exist")

# add|update  new key:value

movie["genre"]="action"
movie["rating"]=7.5


print(movie)
