"""
collections used for storing and organizing many values(objects) in one place instead creating
multiple variable

colllections:
    list methods
    tuple
    set
    dictionary

"""

