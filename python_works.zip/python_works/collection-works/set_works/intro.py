# set

# define {10,"hello","hai",True} set()
# unordered indexing not supported
# mutable 
# duplicates not allowd all items are unique
# methods

# python applications and features


"""
class set:

    def union(self,stobject):
    
    def intersection(self,set_obj):
    
    def difference(self,set_object):
    
    def issubset(self,set_object):
    
    def issuperset(self,set_object):
    
    def symmetric_difference(self,set_object)

    def isdisjoint(self,set_object)

    def update(self,set_object)

    def remove(self,object)

"""

st1={10,20,30,40}

st2={100,200,300}

print(st1.isdisjoint(st2))

# print(st1.issuperset(st2)) #true

# print(st2.issubset(st1))#true

# union_set= st1.union(st2)
# print(union_set)

# intersection_set = st1.intersection(st2)
# print(intersection_set)


# diff_set = st1.difference(st2)
# print(diff_set)
# st={10,"hai",True,10,"hai"}

# print(st[0]) #indexing not supported

# print(st)


# tuple,set
# dictionary 

# dictionary
# list
# set
# tuple