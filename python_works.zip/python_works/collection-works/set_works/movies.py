# add(self,object)

tamil_movies={"kooli","thupaky","kakkamuttai"}

movies={"ARM","Lokah","KGF","kanthara"}


# all_movies=movies.union(tamil_movies)

# print(all_movies)

movies.update(tamil_movies)

print(movies)