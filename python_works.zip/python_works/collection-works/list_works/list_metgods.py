
"""
class list:

    def append(self,object): # appends object to end of list object
    def insert(self,index,object): add object at specified index
    def pop(self,index=-1) remove and return item at specified index 
    def index(self,object) return first index of value
    def count(self,object)Return number of occurrences of object.
    def reverse(self) reverse the current list object
    def copy() return shallow copy of the list  | deep copy
    def sort(self,reverse=False)
    def extend(self,iterable)Extend list by appending elements from the iterable.
    def remove(self,object) remove first occurance of object



"""


colors=["red","green","blue","yellow","red"]
#         0      1      2       3       3

colors.remove("red")

print(colors)
