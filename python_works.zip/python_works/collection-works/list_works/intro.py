

expenses=[10000,12000,11000,13000,14000,15000]
#           0     1     2     3     4     5
#           i

# for exp in expenses:

#     print(exp)


for i in range(0,len(expenses)):

    print(expenses[i])