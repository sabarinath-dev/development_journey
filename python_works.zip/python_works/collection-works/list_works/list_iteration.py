

numbers=[100,200,300,400,400,500]
#         0    1   2   3   4  5
#         i                    

for index in range(0,len(numbers)):

    print(numbers[index])

print("===============")

for num in numbers:

    print(num)






