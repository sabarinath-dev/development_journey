# tuple used for organizing and storing multpliple values using single variable

# define (),tuple()
# dulicates allowed
# ordered
# immutable
# methods
"""
class tuple:

    def count(self,object) return number occurance of object

    def index(self,object) return first index postion of object

"""



tp=(10,20,10,20)
#    0  1

freq=tp.count(10)
print(freq)

pos=tp.index(20)
print(pos)


