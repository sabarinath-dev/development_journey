
# builtin.py
# print()
# input()

