

"""
lambda function
    defnition:anonymous function with one expression

    def function_name(p1,p2,,,pn):    
        return value

    def add_number(n1,n2):
        return n1+n2
  
    syntax:
       reference_name = lambda p1,p2,p3,,pn:expression

       add=lambada n1,n2:n1+n2

       cube=labda n:n**3
    
"""


