



file_path="C:\\Users\\Luminar\\Desktop\\development_journey_july_2k25\\python_works\\Fileworks\\frameworks.txt"


fw=open(file_path,"w")

fw.write("django")