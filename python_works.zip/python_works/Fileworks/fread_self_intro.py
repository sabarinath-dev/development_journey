
# step1:open file

file_path="C:\\Users\\Luminar\\Desktop\\development_journey_july_2k25\\python_works\\Fileworks\\self_intro.txt"


fr=open(file_path,"r")

for line in fr:

    print(line)