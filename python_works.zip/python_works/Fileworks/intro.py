"""
Files

:to store data permenantly

file operation:
    read=>r
    write=>w
    append=>a

function used for creating file refernce

ref_name=open(file_path,mode)

"""