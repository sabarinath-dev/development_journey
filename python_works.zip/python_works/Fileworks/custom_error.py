


num1=int(input("enter number1"))

num2=int(input("enter  umber2"))


if  num2<=0:

    raise Exception("number can't be zero")


res=num1/num2

print(res)


# assert debugging

