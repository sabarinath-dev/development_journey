

"""
membership operator(in)

chks a value exist in sequence(string,list,tuple,set,dictionary) or not

"""

text="chicken"

print("hen" in text)


roll_number=1010

print(10 in roll_number)



# assignment operator (=)