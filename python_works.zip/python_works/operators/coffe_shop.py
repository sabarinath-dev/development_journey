

#  5 coffe 
bill_total = 185

head_count = 5

tip_amount = 25

gst = (5/100)*bill_total

total_bill_amount = bill_total+tip_amount+gst


individual_split = total_bill_amount / head_count

print(individual_split)


# cal culate BMR



# height_in_cm
# weight_in_kg
# BMI=weight_in_kg/(height_in_meter**2) # 22.3