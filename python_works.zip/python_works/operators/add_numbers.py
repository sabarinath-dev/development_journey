

# read name and age  and display


# jhon your next birthday you will be age+1
 
name = input("enter name ") #jhon

age =int( input("enter age ")) #age+1#" 24"

print(name,"your next birthday you will be",age+1)