


number = int(input("enter number")) # 

# Dispaly True or False based on last digit of number > 5 

last_digit = number % 10 # 7

print(last_digit > 5)


# read a number num
# display T or F based of number is divisible by 4

# q1 read temp in degree celsious convert into Fh

# q2 read temp in fh convert ito degree celsious

# q3 read kilometer and convert into meter

# condition chk

# logical operator Decision making

# A.O(+,-,/,*,//,%,**)

#C.O(<,>,<=,>=,==,!=)


# LogicalOperators(and,or,not)