# Assignment operator (=,+=,-=,*=)

# ++,-- XXXXXX
num = 10


num *=2

print(num)

# operators are symbols used to perform operations

# AssignmentOperator [=,+=,-=,*=,,,,]
# Relational Operator[>,<,>=,<=,==,!=]
# Arithmetic Operator[+,-,/,//,*,**,%]
# LogicalOperator[and,or,not]
# Identity Operator[is]
# MembershipOperator[in]

# DecisionMaking statements 

# if.else

# if...elif...else

signal= input("enter signal") 

print("STOP XXXXXXXX")
print("GO>>>>>")
print("WAIT !!!!!!!!!")




