
# print(True and False) # False  

# print(False or True)#True

# print(not False) # True
