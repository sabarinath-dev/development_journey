

# Comparison operator (<,>,<=,>=,==,!=)

num1 = 10

num2=20


print(num1 > num2) # 10 > 20 : False

print(num1 < num2) # 10< 20 True

print( num1 == num2)

print(num1 != num2)

print(False < True) # not reco


# True:1

