# read two numbers num1,num2 and display total

num1 = int(input("enter num1 "))#10

num2 = int(input("enter number2 "))#20

total = num1 + num2#total= 30

print(num1,"+",num2,"=",total)# 10 + 20 = 30

