
"""
identity operator (is)

This operator chks two objects(variables) are pointing to same memory location or not

"""

string1="a man a plan a canal panama"

string2="a man a plan a canal panama"


print(string1 == string2)

print(string1 is string2)


# membership operator