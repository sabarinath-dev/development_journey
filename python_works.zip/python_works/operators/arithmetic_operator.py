
# print("message")
# read value through console input("message")

name = input("enter user name")

age = input("enter age")

#  {name} is {age} years old 

print(name,"is",age,"years old")

