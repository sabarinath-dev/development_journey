

# 1800-2025

for num in range(1800,2026):

    print(num)

    