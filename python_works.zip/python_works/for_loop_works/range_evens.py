

# display all even numbers from 50 to 100

for num in range(50,101):

    if num%2==0:

        print(num)


# chk number is prime or not

number = 7

(1,7)

number = 23
(1,23)

number =8
(1,2,4,8)


