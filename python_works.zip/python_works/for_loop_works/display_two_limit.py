

limit = int(input("enter limit "))

for num in range(2,limit):

    print(num)