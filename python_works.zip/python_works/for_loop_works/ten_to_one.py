# display numbers from 10 to 1

for num in range(10,0,-1):

    print(num)



limit = 50

