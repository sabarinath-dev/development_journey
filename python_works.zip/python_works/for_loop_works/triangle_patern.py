

# *
# * *
# * * *
# * * * *
# * * * * *
# * * * * * *

# for row in range(1,7):

#     print(row*" *")



  

# * * * * * * (6) 
# * * * * * (5)
# * * * *  (4)
# * * *  (3)
# * *  (2)
# *  (1)



for row in range(1,7):

    for col in range(row,7):# 1,7 (6) 2,6 3,6 4,6 5,6

        print("*",end=" ")
    
    print()




#q2

"""
       *
      * * 
     * * *   
    * * * *
"""

# functions 

