

# visit 5 floor 8 step in each floor

#     c1 c2 c3 c4 c5 
#r1   1   2  3  4 5
#r2   1   2  3  4 5
#r3   1   2  3  4 5
#r4   1   2  3  4 5



for row in range(1,5):

    for col in range(1,6):

        print(col,end=" ")

    print()



