


number = int(input("enter number"))

for i in range(1,number+1):

    if number%i==0:

        print(i)



"""
read two number num1,num2

display common divisors of num1 and num2

num1=12
num2=24
o/p =>1,2,3,4,6,12,
"""

