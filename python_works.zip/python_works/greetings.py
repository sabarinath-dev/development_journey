

print("good morning")