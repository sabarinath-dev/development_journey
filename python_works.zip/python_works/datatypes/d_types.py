

# datatype
# type of value that variable holds

# Numerical Type(int,float)
# String Type(str)
# Boolean Type(True,False)
# Collection type(list,set,tuple,dictionary)
# NonType(none)

customer_name ="""jhon""""" 

print(type(customer_name))

is_active =True

print(type(is_active))

balance = 5678.98

print(type(balance))

is_exist = None

print(type(is_exist))


num1 = 10
num2= 5

result = num1/ num2 #10/5=2.0

print(result)
print(type(result))

