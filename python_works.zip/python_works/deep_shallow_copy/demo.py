


basith=[
    ["tea","puttu"],#0
    #   0     1
    ["biriyani","limejuice"],#1
    ["tea"],#2
    ["friedrice"]#3
]


renjith=basith

renjith[0][0]="coffee"

print("basith menu",basith)

print("renjith menu",renjith)