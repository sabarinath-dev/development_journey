

# variables 

# variables are used for representing a value

# syntax

# variable_name = value

# variable_name should starts with alphabet
# specialcharacter (_)
# there is no length limit
# noun
person_name = "jhon smith"

age = 34

place = "uk"

# hello all i am jhonsmith from uk am 34 years old

print("hello all i am",person_name,"from",place,"am",age,"years old")



bank_name ="sbi"

acc_number=-1224

balance = 1234

# hello sbi user your account 1224 avl bal is 1234
# data types an operators